﻿using System;
class Program
{
    public static int MostFreq(int[] a, out int x)
    {

        int mostFreq, numbFreq, i, k;

        Array.Sort(a);

        k = a[0];

        mostFreq = 0; i = 0; x = 0;

        while (i < a.Length)
        {
            numbFreq = 0;

            while (k == a[i])
            {
                numbFreq++;
                i++;
                if (i == a.Length)
                    break;
            }

            if (numbFreq > mostFreq)
            {
                mostFreq = numbFreq;
                x = k;
            }

            if (i < a.Length)
                k = a[i];

        }
        return (mostFreq);
    }
    static void Main()
    {
        Console.WriteLine("Введите размерность массива:");
        int n = Convert.ToInt32(Console.ReadLine());
        int[] arr = new int[n];
        Console.WriteLine("Введите массив:");
        string[] str = Console.ReadLine().Split(new char[] { ' ', '\n', '\t' }, StringSplitOptions.RemoveEmptyEntries);
        for (int i = 0; i < (n < str.Length ? n : str.Length); ++i)
            arr[i] = Convert.ToInt32(str[i]);
        int x;
        int f = MostFreq(arr, out x);
        Console.WriteLine("Number = {0} Count = {1}", x, f);
        Console.ReadKey();
    }

}


