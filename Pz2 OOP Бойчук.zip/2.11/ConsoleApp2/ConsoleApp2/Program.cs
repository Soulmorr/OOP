﻿using System;
class Program
{
    static void Main(string[] args)
    {

        Console.WriteLine("Введите размерность массива:");
        int n = Convert.ToInt32(Console.ReadLine());
        int[] arr = new int[n];
        Console.WriteLine("Введите массив:");
        string[] str = Console.ReadLine().Split(new char[] { ' ', '\n', '\t' }, StringSplitOptions.RemoveEmptyEntries);
        for (int i = 0; i < (n < str.Length ? n : str.Length); ++i)
            arr[i] = Convert.ToInt32(str[i]);
        int sum1 = 0, sum2 = 0;
        bool end = false;

        for (int i = 1; i < arr.Length - 1; i++)
        {
            for (int j = 0; j < i; j++)
            {
                sum1 = sum1 + arr[j];
            }
            for (int j = i + 1; j < arr.Length; j++)
            {
                sum2 = sum2 + arr[j];
            }
            if (sum1 == sum2)
            {
                Console.WriteLine(i);
                end = true;
            }
            sum1 = 0;
            sum2 = 0;
        }
        if (arr.Length == 1)
        {
            Console.WriteLine("0");
        }
        else
        if (end == false)
        {
            Console.WriteLine("no");
        }
        Console.ReadKey();
    }
}

