﻿using System;

namespace ConsoleApp2
{
    class Program
    {
        static void Main(string[] args)
        {
            string line;
            line = Console.ReadLine();
            for (int i = 0; i < line.Length; i++)
            {
                Console.WriteLine(line[i] + " -> " + ((int)line[i] - 97));
            }
            Console.ReadKey();
        }
    }
}
