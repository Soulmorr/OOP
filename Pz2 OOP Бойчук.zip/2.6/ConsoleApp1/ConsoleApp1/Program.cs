﻿using System;

class Program
{
    static void Main(string[] args)
    {

         Console.WriteLine("Введите размерность массива:");
         int n = Convert.ToInt32(Console.ReadLine());
         int[] arr = new int[n];
         Console.WriteLine("Введите массив:");
         string[] str = Console.ReadLine().Split(new char[] { ' ', '\n', '\t' }, StringSplitOptions.RemoveEmptyEntries);
         for (int i = 0; i < (n < str.Length ? n : str.Length); ++i)
             arr[i] = Convert.ToInt32(str[i]);
        int len = 1;
        int bestlen = len;
        int start = 0, bestStart = 0;
        for (int i = 1; i < arr.Length; i++)
        {

            if (arr[i] == arr[i - 1])
            {
                len++;
                start = arr[i];
                if (len > bestlen)
                    bestStart = start;
            }
            else
            {


                if (len > bestlen)
                {
                    bestStart = start;
                    bestlen = len;
                    len = 1;
                    start = 0;
                }
                else
                {
                    len = 1;
                }
            }

        }

        
        if (bestlen == 1)
        {
            for (int i = 0; i < len; i++)
            {
                Console.Write(bestStart + " ");
            }
        }
        else
        {
            for (int i = 0; i < bestlen; i++)
            {
                Console.Write(bestStart + " ");
            }
        }
        Console.ReadKey();

    }
}
