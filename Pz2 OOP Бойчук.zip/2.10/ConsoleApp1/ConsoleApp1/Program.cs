﻿using System;
class Program
{
    static void Main(string[] args)
    {

        Console.WriteLine("Введите размерность массива:");
        int n = Convert.ToInt32(Console.ReadLine());
        int[] arr = new int[n];
        Console.WriteLine("Введите массив:");
        string[] str = Console.ReadLine().Split(new char[] { ' ', '\n', '\t' }, StringSplitOptions.RemoveEmptyEntries);
        for (int i = 0; i < (n < str.Length ? n : str.Length); ++i)
            arr[i] = Convert.ToInt32(str[i]);
        int count = 0;
        int search;

        search = Convert.ToInt32(Console.ReadLine());

        for (int i = 0; i < arr.Length; i++)
        {
            for (int j = 0; j < arr.Length; j++)
            {
                if (search == arr[i] + arr[j] || search == arr[i] - arr[j] || search == arr[j] - arr[i])
                {
                    count++;
                }
            }
        }
        Console.WriteLine(count / 2);
        Console.ReadKey();

    }
}

