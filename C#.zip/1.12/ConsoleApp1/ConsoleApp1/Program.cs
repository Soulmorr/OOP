﻿using System;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            float a = Convert.ToInt32(Console.ReadLine());

            bool result=false;
            if (a > 20 && (a % 2) != 0)
                  result = true;
            else
               result = false;

            Console.WriteLine(result);

            Console.ReadKey();
        }
    }
}
