﻿using System;

namespace ConsoleApp2
{
    class Program
    {
        static void Main(string[] args)
        {
             float a = Convert.ToInt32(Console.ReadLine());



            int b = Convert.ToInt32(Console.ReadLine());


            float c = Convert.ToInt32(Console.ReadLine());
            string avg="";
            if (a > 0 && b > 0 && c > 0 || a > 0 || b > 0 || c > 0)
                avg = "Positive";
            else
                if (a < 0 && b < 0 && c < 0 || a < 0 || b < 0 || c < 0)
                avg = "negative";
                Console.WriteLine(avg);


            Console.ReadKey();
        }
    }
}
