﻿using System;

namespace ConsoleApp2
{
    class Program
    {
        static void Main(string[] args)
        {

            int number = Convert.ToInt32(Console.ReadLine());

            int n = Convert.ToInt32(Console.ReadLine());

            int ndigit = (number/(Convert.ToInt32(Math.Pow(10,n-1)))) % 10;
            if(n > number.ToString().Length)
                Console.WriteLine("-");
            else
            Console.WriteLine(ndigit);
        }
    }
}
