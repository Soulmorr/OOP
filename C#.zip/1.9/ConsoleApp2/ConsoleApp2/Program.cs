﻿using System;

namespace ConsoleApp2
{
    class Program
    {
        static void Main(string[] args)
        {

            float a = Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter second number: ");

            int b = Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter third number: ");

            float h = Convert.ToInt32(Console.ReadLine());
            float area = ((a + b) /2) * h;
            Console.WriteLine(area);
        }
    }
}
