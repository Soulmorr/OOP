﻿using System;

namespace ConsoleApp2
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = Convert.ToInt32(Console.ReadLine());


          long result=1;
            if (n == 1 || n == 0)
                result = 1;
            else
            for(int i = 2; i <=n; i++)
                {
                    result = result * i;
                }
            Console.WriteLine(result);
        }
    }
}
