﻿using System;
using System.Dynamic;

namespace ConsoleApp2
{
    class Program
    {
        static void Main(string[] args)
        {
            int a = Convert.ToInt32(Console.ReadLine());

            bool result;
            if (a % 9 == 0 || a % 11 == 0 ||  a % 13 == 0)
                result = true;
            else
                result = false;
            Console.WriteLine(result);


            Console.ReadKey();
        }
    }
}
