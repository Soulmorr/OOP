﻿using System;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            double a, b, c;
            string p = Console.ReadLine();
            string q = Console.ReadLine();
            string w = Console.ReadLine();
            a = Convert.ToDouble(p);
            b = Convert.ToDouble(w);
            c = Convert.ToDouble(q);
            double g=0;
            g = (a + b + c) / 3;
            Console.WriteLine(g.ToString());
            Console.ReadKey();
        }
    }
}
