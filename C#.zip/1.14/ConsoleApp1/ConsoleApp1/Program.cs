﻿using System;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            int a = Convert.ToInt32(Console.ReadLine());
            int b = Convert.ToInt32(Console.ReadLine());
            int c = Convert.ToInt32(Console.ReadLine());
            int result;
            if (a > b)
                if (a > c) result=a;
                else result = c;
            else
            if (b > c)
                result = b;
            else 
                result = c;

            Console.WriteLine(result);


            Console.ReadKey();
            
        }
    }
}
