﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
namespace ConsoleApp1
{
    class Program
    {
        class Dough
        {
            private float weight;
            private string type;
            private string technique;
            public float Calories { get => CalculateCalories(); }
            public float Weight
            {
                get { return weight; }
                set
                {
                    if (value < 1 || value > 200)
                    {
                        throw new Exception("Dough weight should be in the range [1..200].");
                    }
                    else
                    {
                        weight = value;
                    }
                }
            }
            public string Type
            {
                get { return type; }
                set
                {
                    if (value != "White" && value != "Wholegrain")
                    {
                        throw new Exception("Invalid type of dough.");
                    }
                    else
                    {
                        type = value;
                    }
                }
            }
            public string Technique
            {
                get { return technique; }
                set
                {
                    if (value != "Crispy" && value != "Chewy" && value != "Homemade")
                    {
                        throw new Exception("Invalid type of dough.");
                    }
                    else
                    {
                        technique = value;
                    }
                }
            }
            public Dough(float w, string ty, string te)
            {
                Weight = w;
                Type = ty;
                Technique = te;
            }
            private float CalculateCalories()
            {
                float x, y, result;
                if (type == "White")
                {
                    x = 1.5F;
                }
                else
                {
                    x = 1.0F;
                }
                if (technique == "Crispy")
                {
                    y = 0.9F;
                }
                else if (technique == "Chewy")
                {
                    y = 1.1F;
                }
                else
                {
                    y = 1.0F;
                }
                result = weight * 2 * x * y;
                return result;
            }
        }
        class Pizza
        {
            private string name;
            private Dough dough;
            private List<Topping> listOfToppings = new List<Topping>();
            private float AllCalories = 0;
            public string Name
            {
                get { return name; }
                set
                {
                    if (value == null || value == "")
                    {
                        throw new Exception("Pizza name cannot be empty");
                    }
                    else if (value.Length > 15)
                    {
                        throw new Exception("Pizza name should be between 1 and 15 symbols.");
                    }
                    else
                    {
                        name = value;
                    }
                }
            }
            public void AddDough(Dough dough)
            {
                this.dough = dough;
                AllCalories += dough.Calories;
            }
            public void AddTopping(Topping topping)
            {
                listOfToppings.Add(topping);
                AllCalories += topping.Calories;
                if (listOfToppings.Count > 10)
                {
                    throw new Exception("Number of toppings should be in range [0..10].");
                }
            }
            public void Output()
            {
                Console.
                    WriteLine($"{Name} - {AllCalories:0.00} Calories.");
            }
            public Pizza(string name)
            {
                Name = name;
            }

        }
        class Topping
        {
            private float weight;
            private string type;
            public float Calories { get => CalculateCalories(); }
            public float Weight
            {
                get { return weight; }
                set
                {
                    if (value < 1 || value > 50)
                    {
                        throw new Exception($"{type} weight should be in the range [1..50].");
                    }
                    else
                    {
                        weight = value;
                    }
                }
            }
            public string Type
            {
                get { return type; }
                set
                {
                    if (value != "Meat" && value != "Veggies" && value != "Cheese" && value != "Sauce")
                    {
                        throw new Exception($"Cannot place {value} on top of your pizza.");
                    }
                    else
                    {
                        type = value;
                    }
                }
            }
            public Topping(float w, string ty)
            {
                Type = ty;
                Weight = w;
            }
            private float CalculateCalories()
            {
                float x, result;
                if (type == "Meat")
                {
                    x = 1.2F;
                }
                else if (type == "Veggies")
                {
                    x = 0.8F;
                }
                else if (type == "Cheese")
                {
                    x = 1.1F;
                }
                else if (type == "Sauce")
                {
                    x = 0.9F;
                }
                else
                {
                    x = 0;
                }
                result = weight * 2 * x;
                return result;
            }
        }
        static void Main(string[] args)
        {
            try
            {
                string[] str = Console.ReadLine().Split(' ');
                Pizza pizza = new Pizza(str[1]);
                for (int i = 0; i < 30; i++)
                {
                    string[] s = Console.ReadLine().Split(' ');
                    if (s[0] == "END")
                    {
                        break;
                    }
                    else if (s[0] == "Dough")
                    {
                        pizza.AddDough(new Dough(float.Parse(s[3]), s[1], s[2]));
                    }
                    else
                    {
                        pizza.AddTopping(new Topping(float.Parse(s[2]), s[1]));
                    }
                }
                pizza.Output();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"{ex.Message}");
            }
            Console.ReadKey();
        }
    }
}
