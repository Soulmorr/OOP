﻿using System;
using System.Dynamic;

namespace ConsoleApp1
{
    class Program
    {
        class Car
        {
            public string model { get; }
            public Engine carengine { get; }
            public Cargo cargo { get; }
            public Tire[] tires = new Tire[4];
            public Car(string model, int Speed, int Power, int weight, string type, double pressure0, int age0, double pressure1, int age1, double pressure2, int age2, double pressure3, int age3)
            {
                this.model = model;
                carengine = new Engine();
                carengine.speed = Speed;
                carengine.power = Power;
                cargo = new Cargo();
                cargo.weight = weight;
                cargo.type = type;
                tires[0] = new Tire();
                tires[0].age = age0;
                tires[0].pressure = pressure0;
                tires[1] = new Tire();
                tires[1].age = age1;
                tires[1].pressure = pressure1;
                tires[2] = new Tire();
                tires[2].age = age2;
                tires[2].pressure = pressure2;
                tires[3] = new Tire();
                tires[3].age = age3;
                tires[3].pressure = pressure3;
            }
 
            static public void Fragile(Car[] car, int n)
            {
                for (int i = 0; i < n; i++)
                {
                    if (car[i].cargo.type == "fragile")
                    {
                        for (int j = 0; j < 4; j++)
                        {
                            if (car[i].tires[j].pressure < 1)
                            {
                                Console.WriteLine($"{car[i].model}");
                                break;
                            }
                        }
                    }
                }

            }
            static public void Flamable(Car[] car, int n)
            {
                for (int i = 0; i < n; i++)
                {
                    if (car[i].cargo.type == "flamable" && car[i].carengine.power > 250)
                    {
                        Console.WriteLine($"{car[i].model}");
                    }
                }

            }
        }
            public class Engine
            {
                public int speed { get; set; }
                public int power { get; set; }


            }
            public class Cargo
            {
                public int weight { get; set; }
                public string type { get; set; }

            }
            public class Tire
            {
                public int age;
                public double pressure;
            }
            



            static void Main(string[] args)
            {
                int N = Convert.ToInt32(Console.ReadLine());
                Car[] car = new Car[N];
                for (int i = 0; i < N; i++)
                {
                    string[] s = Console.ReadLine().Split(' ');
                    car[i] = new Car(s[0], Convert.ToInt32(s[1]), Convert.ToInt32(s[2]), Convert.ToInt32(s[3]), s[4], Convert.ToDouble(s[5]), Convert.ToInt32(s[6]), Convert.ToDouble(s[7]), Convert.ToInt32(s[8]), Convert.ToDouble(s[9]), Convert.ToInt32(s[10]), Convert.ToDouble(s[11]), Convert.ToInt32(s[12]));
                }
                string r = Console.ReadLine();
                if (r == "fragile")
                {
                    Car.Fragile(car, N);
                }
                else
                {
                    Car.Flamable(car, N);
                }
                Console.ReadKey();
            }
        }
    }


