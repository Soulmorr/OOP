﻿using System;
using System.Collections.Generic;
namespace ConsoleApp2
{
    class Program
    {
        abstract class Person
        {
            public List<int> Stars = new List<int>();
            public int row { get; set; }
            public int col { get; set; }
            public int Sum { get; set; }
            abstract public void AddElements(Galaxy galaxi);
        }

        class Ivo : Person
        {
            public override void AddElements(Galaxy galaxy)
            {
                int n = row;
                int m = col;
                while (m < galaxy.dimention.GetLength(1) && n >= 0)
                {
                    Stars.Add(galaxy.dimention[n, m]);
                    Sum += galaxy.dimention[n, m];
                    n--;
                    m++;
                }
            }
        }
        class Evil : Person
        {
            public override void AddElements(Galaxy galaxy)
            {
                int n = row;
                int m = col;
                while (n >= 0 && m >= 0)
                {
                    Stars.Add(galaxy.dimention[n, m]);
                    Sum += galaxy.dimention[n, m];
                    n--;
                    m--;
                }
            }
        }
        class Galaxy
        {
            public int[,] dimention;
            public void Input(int n, int m)
            {
                dimention = new int[n, m];
                int value = 0;
                for (int i = 0; i < n; i++)
                {
                    for (int j = 0; j < m; j++)
                    {
                        dimention[i, j] = value;
                        value++;
                    }
                }
            }
            public static void Compare(Ivo ivo, Evil evil)
            {
                for (int i = 0; i < ivo.Stars.Count; i++)
                {
                    for (int j = 0; j < evil.Stars.Count; j++)
                    {
                        if (ivo.Stars[i] == evil.Stars[j])
                        {
                            ivo.Sum -= ivo.Stars[i];
                            break;
                        }
                    }
                }
            }
        }
        
        static void Main(string[] args)
        {
            Galaxy galaxy = new Galaxy();
            Ivo ivo = new Ivo();
            Evil evil = new Evil();
            string[] l = Console.ReadLine().Split(' ');
            int n = int.Parse(l[0]);
            int m = int.Parse(l[1]);
            galaxy.Input(n, m);
            for (int i = 0; i < 100; i++)
            {
                string[] l1 = Console.ReadLine().Split(' ');
                if (l1[0] == "Let"&& l1[1] == "the"&& l1[2] == "force"&& l1[3] == "be"&& l1[4] == "with"&& l1[5] == "you")
                    break;
                else
                {
                    ivo.row = int.Parse(l1[0]) - 1;
                    ivo.col = int.Parse(l1[1]) + 1;
                    ivo.AddElements(galaxy);
                    string[] s2 = Console.ReadLine().Split(' ');
                    evil.row = int.Parse(s2[0]) - 1;
                    evil.col = int.Parse(s2[1]) - 1;
                    evil.AddElements(galaxy);

                }
            }
            Galaxy.Compare(ivo, evil);
            Console.WriteLine($"{ivo.Sum}");
            Console.ReadKey();
        }
    }
}
