﻿using System;
using System.Collections.Generic;

namespace ConsoleApp1
{
    class Program
    {
        abstract class Person
        {
            public string Name { get; set; }


        }

        class Patient : Person
        {
            public Patient(string name)
            {
                Name = name;
            }
        }

        class Doctor : Person
        {
            public string Surname { get; set; }
            public List<Patient> Patients { get; set; } = new List<Patient>();
            public Doctor(string name, string surname, string patientName)
            {
                Name = name;
                Surname = surname;
                Patients.Add(new Patient(patientName));
            }
            public static bool CheckUnique(string name, string surname, List<Doctor> doctorslist)
            {
                for (int i = 0; i < doctorslist.Count; i++)
                {
                    if (doctorslist[i].Name == name)
                    {
                        return false;
                    }
                }
                return true;
            }
            public static void SortAndOutputPatients(string name, string surname, List<Doctor> doctorslist)
            {
                for (int i = 0; i < doctorslist.Count; i++)
                {
                    if (name == doctorslist[i].Name && surname == doctorslist[i].Surname)
                    {
                        for (int k = 0; k < doctorslist[i].Patients.Count; k++)
                        {
                            for (int l = 0; l < doctorslist[i].Patients.Count - 1; l++)
                            {
                                if (string.Compare(doctorslist[i].Patients[k].Name, doctorslist[i].Patients[l].Name) < 0)
                                {
                                    string tmp = doctorslist[i].Patients[k].Name;
                                    doctorslist[i].Patients[k].Name = doctorslist[i].Patients[l].Name;
                                    doctorslist[i].Patients[l].Name = tmp;
                                }
                            }
                        }
                        for (int j = 0; j < doctorslist[i].Patients.Count; j++)
                        {
                            Console.WriteLine(doctorslist[i].Patients[j].Name);
                        }
                    }
                }
            }
            public void AddPatient(string patientName)
            {
                Patients.Add(new Patient(patientName));
            }
        }
        class Department
        {
            public string Name { get; set; }
            public string[,] Room = new string[20, 3];


            public Department(string name, string doctorName, string doctorSurname, string patientName)
            {
                Name = name;
                AddPatient(patientName);
            }
            public void AddPatient(string name)
            {
                int k = 0;
                for (int i = 0; i < 20; i++)
                {
                    for (int j = 0; j < 3; j++)
                    {
                        if (Room[i, j] == null)
                        {
                            Room[i, j] = name;
                            k++;
                            break;
                        }
                    }
                    if (k == 1)
                    {
                        break;
                    }
                }
            }
            public static bool CheckUnique(string name, List<Department> departments)
            {
                int k = 0;
                for (int i = 0; i < departments.Count; i++)
                {
                    if (departments[i].Name == name)
                    {
                        k++;
                        break;
                    }
                }
                if (k == 0)
                    return true;
                else
                    return false;
            }
            public void Output()
            {
                for (int i = 0; i < 20; i++)
                {
                    for (int j = 0; j < 3; j++)
                    {
                        if (Room[i, j] != null)
                        {
                            Console.WriteLine($"{Room[i, j]}");
                        }
                    }
                }
            }
            public void Output(int n, List<Department> departments)
            {
                List<string> Names = new List<string>();

                n--;
                for (int j = 0; j < 3; j++)
                {
                    if (Room[n, j] == null)
                    {
                        break;
                    }
                    else
                    {
                        Names.Add(Room[n, j]);
                    }
                }
                for (int i = 0; i < Names.Count; i++)
                {
                    for (int j = 0; j < Names.Count; j++)
                    {
                        if (string.Compare(Names[i], Names[j]) < 0)
                        {

                            string tmp = Names[i];
                            Names[i] = Names[j];
                            Names[j] = tmp;
                        }
                    }
                }
                for (int j = 0; j < Names.Count; j++)
                {
                    Console.WriteLine(Names[j]);
                }
            }
        }
        
        static void Main(string[] args)
        {
            List<Department> departments = new List<Department>();
            List<Doctor> doctorslist = new List<Doctor>();
            for (int i = 0; i < 30; i++)
            {
                string[] s = Console.ReadLine().Split(' ');
                if (s[0] == "Output")
                {
                    break;
                }
                else
                {
                    if (Doctor.CheckUnique(s[1], s[2], doctorslist))
                        doctorslist.Add(new Doctor(s[1], s[2], s[3]));
                    else
                    {
                        for (int j = 0; j < doctorslist.Count; j++)
                        {
                            if (s[1] == doctorslist[j].Name && s[2] == doctorslist[j].Surname)
                            {
                                doctorslist[j].AddPatient(s[3]);
                            }
                        }
                    }
                    if (Department.CheckUnique(s[0], departments) == true)
                    {
                        departments.Add(new Department(s[0], s[1], s[2], s[3]));
                    }
                    else
                    {
                        for (int j = 0; j < departments.Count; j++)
                        {
                            if (departments[j].Name == s[0])
                            {
                                departments[j].AddPatient(s[3]);
                            }
                        }
                    }

                }
            }
            string[] s1 = Console.ReadLine().Split(' ');
            if (s1.Length == 1)
            {
                for (int i = 0; i < departments.Count; i++)
                {
                    if (departments[i].Name == s1[0])
                    {
                        departments[i].Output();
                    }
                }
            }
            else if (s1.Length == 2)
            {
                if (int.TryParse(s1[1], out int int_value))
                {

                    for (int i = 0; i < departments.Count; i++)
                    {
                        if (departments[i].Name == s1[0])
                        {
                            departments[i].Output(int_value, departments);
                        }
                    }
                }
                else
                {
                    Doctor.SortAndOutputPatients(s1[0], s1[1], doctorslist);
                }

            }

            Console.ReadKey();
        }
    }
    
}
