﻿using System;
using System.Collections.Generic;
namespace ConsoleApp1
{
    class Program
    {
        class Car
        {
            public string Model { get; set; }
            public string Engine { get; set; }
            public int Weight { get; set; }
            public string Color { get; set; }
            public Car(string model, string engine, int weight = 0, string color = "n/a")
            {
                Model = model;
                Engine = engine;
                Weight = weight;
                Color = color;
            }
        }
        class Engine
        {
            public string Model { get; set; }
            public int Power { get; set; }
            public int Displacement { get; set; }
            public string Efficiency { get; set; }
            public Engine(string model, int power, int displacement = 0, string efficiency = "n/a")
            {
                Model = model;
                Power = power;
                Displacement = displacement;
                Efficiency = efficiency;
            }
        }
     
        abstract class Complection
        {
            public List<Car> cars = new List<Car>();
            public List<Engine> engines = new List<Engine>();
            public abstract void print();
        }
        class Output : Complection
        {
            public override void print()
            {
                for (int i = 0; i < cars.Count; i++)
                {
                    for (int j = 0; j < engines.Count; j++)
                    {
                        if (engines[j].Model == cars[i].Engine)
                        {
                            Console.WriteLine($"{cars[i].Model}");
                            Console.WriteLine($"  {cars[i].Engine}:");
                            Console.WriteLine($"    Power: {engines[j].Power}");
                            if (engines[j].Displacement == 0)
                                Console.WriteLine($"    Displacement: n/a");
                            else
                                Console.WriteLine($"    Displacement: {engines[j].Displacement}");
                            Console.WriteLine($"    Efficiency: {engines[j].Efficiency}");
                            if (cars[i].Weight == 0)
                                Console.WriteLine($"  Weight: n/a");
                            else
                                Console.WriteLine($"  Weight: {cars[i].Weight}");
                            Console.WriteLine($"  Color: {cars[i].Color}");
                        }
                    }
                }
            }
        }
        static void Main(string[] args)
        {
            Output output = new Output();
            int n = Convert.ToInt32(Console.ReadLine());
            for (int i = 0; i < n; i++)
            {
                string[] s = Console.ReadLine().Split(' ');
                if (s.Length == 4)
                    output.engines.Add(new Engine(s[0], int.Parse(s[1]), int.Parse(s[2]), s[3]));
                if (s.Length == 3)
                {
                    if (s[2][0] <= 'A')
                        output.engines.Add(new Engine(s[0], int.Parse(s[1]), int.Parse(s[2])));
                    if (s[2][0] >= 'A')
                        output.engines.Add(new Engine(s[0], int.Parse(s[1]), 0, s[2]));
                }
                if (s.Length == 2)
                    output.engines.Add(new Engine(s[0], int.Parse(s[1])));
            }
            int m = Convert.ToInt32(Console.ReadLine());
            for (int i = 0; i < m; i++)
            {
                string[] s = Console.ReadLine().Split(' ');
                if (s.Length == 4)
                    output.cars.Add(new Car(s[0], s[1], int.Parse(s[2]), s[3]));
                if (s.Length == 3)
                {
                    if (s[2][0] <= 'A')
                        output.cars.Add(new Car(s[0], s[1], int.Parse(s[2])));
                    if (s[2][0] >= 'A')
                        output.cars.Add(new Car(s[0], s[1], 0, s[2]));
                }
                if (s.Length == 2)
                    output.cars.Add(new Car(s[0], s[1]));

            }
            output.print();
            Console.ReadKey();
        }
    }
}
