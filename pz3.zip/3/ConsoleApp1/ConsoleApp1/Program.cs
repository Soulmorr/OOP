﻿using System;
using System.Collections.Generic;

namespace ConsoleApp1
{
    class Program
    {
        class Person
        {
            private string name;
            private int age;
            public string Name
            {
                get => name;
                set => name = value;
            }
            public int Age
            {
                get => age;
                set => age = value;
            }
            public Person(string name, int age)
            {
                this.name = name;
                this.age = age;
            }

            public Person()
            {
            }
        }
        class Family
        {
            Person[] person;
            private int k = 0;
            public Family(int n)
            {
                person = new Person[n];
            }

            public void AddMember(Person member)
            {
                person[k] = member;
                k++;
            }
            public Person GetOldest()
            {
                int ageofoldest = -1;
                int numbofoldest = 0;
                for (int i = 0; i < k; i++)
                {
                    if (ageofoldest < person[i].Age)
                    {
                        ageofoldest = person[i].Age;
                        numbofoldest = i;
                    }
                }
                return person[numbofoldest];
            }
        }

        static void Main(string[] args)
        {
            int n = Convert.ToInt32(Console.ReadLine());
            Family fam = new Family(n);
            for (int i = 0; i < n; i++)
            {
                string[] info = Console.ReadLine().Split(' ');
                Person tmp = new Person();
                tmp.Name = info[0];
                tmp.Age = Convert.ToInt32(info[1]);
                fam.AddMember(tmp);
            }
            Console.WriteLine($"{fam.GetOldest().Name} {fam.GetOldest().Age}");
            Console.ReadKey();
        }
    }
}
