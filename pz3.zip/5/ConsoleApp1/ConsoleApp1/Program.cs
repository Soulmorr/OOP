﻿using System;

namespace ConsoleApp1
{
    class Program
    {
        class DateModifier
        {
            static public void GetDifference(string a, string b)
            {
                DateTime date1 = DateTime.Parse(a);
                DateTime date2 = DateTime.Parse(b);
                if (DateTime.Compare(date1, date2) < 0) 
                {
                    Console.WriteLine(date2.Subtract(date1).Days); 
                }
                else 
                { 
                    Console.WriteLine(date1.Subtract(date2).Days); 
                }
            }
        }

        static void Main(string[] args)
        {
            string a = Console.ReadLine();
            string b = Console.ReadLine();
            DateModifier.GetDifference(a, b);
            Console.ReadKey();
        }
    }
}
