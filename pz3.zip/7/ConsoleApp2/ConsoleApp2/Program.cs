﻿using System;

namespace ConsoleApp2
{
    class Program
    {
        class Car
        {
            string model;
            double FuelConsumption;
            double FuelAmount;
            int distance;
            public Car(string model, double fuelAm, double fuelCon)
            {
                this.model = model;
                this.FuelAmount = fuelAm;
                this.FuelConsumption = fuelCon;
                this.distance = 0;
            }
            static public void Check(string Model, int Distance, Car[] car, int n)
            {
                for (int i = 0; i < n; i++)
                {
                    if (car[i].model == Model)
                    {
                        if (car[i].FuelAmount / car[i].FuelConsumption > Distance)
                        {
                            car[i].distance += Distance;
                            car[i].FuelAmount -= car[i].FuelConsumption * Distance;
                        }
                        else
                        {
                            Console.WriteLine("not enough fuel");
                        }
                    }
                }
            }
            static public void Print(Car[] car, int n)
            {
                for (int i = 0; i < n; i++)
                {
                    Console.WriteLine($"{car[i].model} {car[i].FuelAmount:0.00} {car[i].distance}");
                }
            }
        }
        static void Main(string[] args)
        {
            int n = Convert.ToInt32(Console.ReadLine());
            string[] a;
            Car[] car = new Car[n];
            for (int i = 0; i < n; i++)
            {
                string[] s = Console.ReadLine().Split(' ');
                car[i] = new Car(s[0], Convert.ToDouble(s[1]), Convert.ToDouble(s[2]));
            }
            for (int k = 0; k < 100; k++)
            {
                a = Console.ReadLine().Split(' ');
                if (a[0] == "Drive")
                {
                    Car.Check(a[1], Convert.ToInt32(a[2]), car, n);
                }
                if (a[0] == "End")
                {
                    Car.Print(car, n);
                    break;
                }
            }
            Console.ReadKey();
        }
    }
}
