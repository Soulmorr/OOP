﻿using System;
using System.ComponentModel.Design.Serialization;

namespace ConsoleApp1
{
    class Person
    {
         private string name;
            private int age;
            public string Name
            {
                get => name;
                set => name = value;
            }
            public int Age
            {
                get => age;
                set => age = value;
            }
            public Person(string name, int age)
            {
                this.name = name;
                this.age = age;
            }

            public Person()
            {
            }
        public void GetInfo()
        {
            Console.WriteLine($"Имя: {name}  Возраст: {age}");
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Person tom = new Person();
            tom.Name = "Tom";
            int k = Convert.ToInt32(Console.ReadLine());
            tom.Age = k;
            tom.GetInfo();      

            tom.Name = "Tom";
            tom.Age = 34;
            tom.GetInfo();
            Console.ReadKey();
        }
    }
}
