﻿using System;

namespace ConsoleApp2
{
    
    class Program
    {
        class Person
    {
        public string Name
        {
            get => name;
            set => name = value;
        }

        public int Age
        {
            get => age;
            set => age = value;
        }

        public Person()
        {
            name = "No name";
            age = 1;
        }

        public Person(int age)
        {
            name = "No name";
            this.age = age;
        }

        public Person(string name, int age)
        {
            this.name = name;
            this.age = age;
        }
        private string name;
        private int age;
    }
        static void Main(string[] args)
        {
            int n = Convert.ToInt32(Console.ReadLine());
            Person[] lel = new Person[n];
            for (int i = 0; i < n; i++)
            {
                string[] info = Console.ReadLine().Split(' ');
                lel[i] = new Person();
                lel[i].Name = info[0];
                lel[i].Age = Convert.ToInt32(info[1]);
            }
            for (int i = 0; i < n; i++)
            {
                for (int j = i + 1; j < n; j++)
                {
                    if (string.Compare(lel[i].Name, lel[j].Name) < 0)
                    {
                        
                        Person tmp = lel[i];
                        lel[i] = lel[j];
                        lel[j] = tmp;
                    }
                }
            }
            for (int i = 0; i < n; i++)
            {
                if (lel[i].Age > 30)
                {
                    Console.WriteLine($"{lel[i].Name} - {lel[i].Age}");
                }
            }
        }
    }
}
