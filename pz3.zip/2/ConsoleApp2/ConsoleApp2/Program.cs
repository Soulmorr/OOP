﻿using System;

namespace ConsoleApp1
{

        class Person
        {
            private int age = 18;
            private string name;
            
            public Person()
            {
                name = "No name";
                age = 1;
            }

            public Person(int age)
            {
                name = "No name";
                this.age = age;
            }
            public Person(string n, int a)
            { 
            name = n; 
            age = a; 
            }
            public void GetInfo()
            {
                Console.WriteLine($"Имя: {name}  Возраст: {age}");
            }
        }
        class Program
        {
            static void Main(string[] args)
            {
                Person sam = new Person("Sam", 25);
                sam.GetInfo();
            }
        }
    
    
}
